package com.example.assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.part1);
    }
    public void ActivityLoad(View view) {
        Intent i = new Intent(MainActivity.this,MainActivitytwo.class);
        startActivity(i);
    }
    public void ActivityLoad2(View view) {
        Intent i = new Intent(MainActivity.this,MainActivitythree.class);
        startActivity(i);
    }
}
